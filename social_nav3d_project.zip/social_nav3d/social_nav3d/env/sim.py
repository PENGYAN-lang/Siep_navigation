from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pybullet as p
import pybullet_data

from ..utils.geometry import Pose2, integrate_diff_drive
from ..utils.social import PersonalSpace


@dataclass
class Pedestrian:
    body_id: int
    radius: float
    xy: np.ndarray
    yaw: float
    vel: np.ndarray
    ps: PersonalSpace


@dataclass
class LidarConfig:
    n_az: int
    n_el: int
    max_range: float
    el_deg: List[float]


class SocialNavSim:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.dt = float(cfg['sim']['dt'])
        self.max_steps = int(cfg['sim']['max_steps'])
        self.gui = bool(cfg['sim']['gui'])
        self.record_video = bool(cfg['sim'].get('record_video', False))
        self.out_dir = Path(cfg['sim'].get('out_dir', 'runs'))
        self.out_dir.mkdir(parents=True, exist_ok=True)

        self.client = p.connect(p.GUI if self.gui else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.resetSimulation(physicsClientId=self.client)
        p.setGravity(0, 0, -9.81, physicsClientId=self.client)
        p.setTimeStep(self.dt, physicsClientId=self.client)

        self.plane_id = p.loadURDF('plane.urdf')
        self._build_world()
        self.robot_id = self._build_robot()
        self.lidar = LidarConfig(**cfg['lidar'])

        self.start = np.array(cfg['robot']['start'], dtype=float)
        self.goal = np.array(cfg['robot']['goal'], dtype=float)
        self.goal_xy = self.goal[:2]
        self.robot_limits = {'max_v': float(cfg['robot']['max_v']), 'max_w': float(cfg['robot']['max_w'])}
        self.robot_pose = Pose2(float(self.start[0]), float(self.start[1]), float(self.start[2]))
        self.max_v = float(cfg['robot']['max_v'])
        self.max_w = float(cfg['robot']['max_w'])
        self.robot_radius = float(cfg['robot']['radius'])

        self.pedestrians: List[Pedestrian] = []
        self._spawn_pedestrians()

    def close(self):
        if p.isConnected(self.client):
            p.disconnect(self.client)

    def _build_world(self):
        # Obstacles: simple boxes
        for obs in self.cfg['world'].get('obstacles', []):
            pos = obs['pos']
            hx, hy, hz = obs['half_extents']
            col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[hx, hy, hz])
            vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[hx, hy, hz], rgbaColor=[0.6,0.6,0.6,1])
            p.createMultiBody(baseMass=0, baseCollisionShapeIndex=col,
                              baseVisualShapeIndex=vis, basePosition=pos)
        # Ramps: tilted boxes
        for r in self.cfg['world'].get('ramps', []):
            pos = r['pos']
            sx, sy, sz = r['size']
            pitch = math.radians(r.get('pitch_deg', 10))
            orn = p.getQuaternionFromEuler([0, pitch, 0])
            col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[sx/2, sy/2, sz/2])
            vis = p.createVisualShape(p.GEOM_BOX, halfExtents=[sx/2, sy/2, sz/2], rgbaColor=[0.3,0.3,0.8,1])
            p.createMultiBody(baseMass=0, baseCollisionShapeIndex=col,
                              baseVisualShapeIndex=vis, basePosition=pos, baseOrientation=orn)

    def _build_robot(self) -> int:
        r = float(self.cfg['robot']['radius'])
        h = float(self.cfg['robot']['height'])
        col = p.createCollisionShape(p.GEOM_CYLINDER, radius=r, height=h)
        vis = p.createVisualShape(p.GEOM_CYLINDER, radius=r, length=h, rgbaColor=[0.1,0.2,0.9,1])
        start = self.cfg['robot']['start']
        body = p.createMultiBody(baseMass=20.0, baseCollisionShapeIndex=col,
                                 baseVisualShapeIndex=vis, basePosition=[start[0], start[1], h/2],
                                 baseOrientation=p.getQuaternionFromEuler([0,0,start[2]]))
        # Add lateral friction
        p.changeDynamics(body, -1, lateralFriction=1.0, rollingFriction=0.01)
        return body

    def _spawn_pedestrians(self):
        n = int(self.cfg['pedestrians']['count'])
        rad = float(self.cfg['pedestrians']['radius'])
        vmin, vmax = self.cfg['pedestrians']['speed_range']
        ps_cfg = self.cfg['pedestrians']['personal_space']
        ps = PersonalSpace(**ps_cfg)

        rng = np.random.default_rng(int(self.cfg.get('seed', 0)))
        for _ in range(n):
            x = float(rng.uniform(3.0, 17.0))
            y = float(rng.uniform(3.0, 17.0))
            yaw = float(rng.uniform(-math.pi, math.pi))
            speed = float(rng.uniform(vmin, vmax))
            vel = np.array([math.cos(yaw), math.sin(yaw)], dtype=float) * speed

            col = p.createCollisionShape(p.GEOM_CAPSULE, radius=rad, height=0.9)
            vis = p.createVisualShape(p.GEOM_CAPSULE, radius=rad, length=0.9, rgbaColor=[0.9,0.2,0.2,1])
            body = p.createMultiBody(baseMass=70.0, baseCollisionShapeIndex=col,
                                     baseVisualShapeIndex=vis, basePosition=[x, y, 0.9/2 + rad])
            p.changeDynamics(body, -1, lateralFriction=1.0)

            self.pedestrians.append(Pedestrian(body_id=body, radius=rad,
                                              xy=np.array([x,y], dtype=float),
                                              yaw=yaw, vel=vel, ps=ps))

    def reset(self) -> Pose2:
        self.robot_pose = Pose2(float(self.start[0]), float(self.start[1]), float(self.start[2]))
        h = float(self.cfg['robot']['height'])
        p.resetBasePositionAndOrientation(self.robot_id,
                                         [self.robot_pose.x, self.robot_pose.y, h/2],
                                         p.getQuaternionFromEuler([0,0,self.robot_pose.yaw]))
        p.resetBaseVelocity(self.robot_id, [0,0,0], [0,0,0])
        return self.robot_pose.copy()

    def _step_pedestrians(self):
        # Simple constant-velocity + wall bounce in XY bounds
        sx, sy = self.cfg['world']['size_xy']
        xmin, ymin, xmax, ymax = 0.5, 0.5, sx-0.5, sy-0.5
        for ped in self.pedestrians:
            ped.xy = ped.xy + ped.vel * self.dt
            # bounce
            if ped.xy[0] < xmin or ped.xy[0] > xmax:
                ped.vel[0] *= -1
                ped.xy[0] = np.clip(ped.xy[0], xmin, xmax)
            if ped.xy[1] < ymin or ped.xy[1] > ymax:
                ped.vel[1] *= -1
                ped.xy[1] = np.clip(ped.xy[1], ymin, ymax)
            ped.yaw = math.atan2(ped.vel[1], ped.vel[0] + 1e-9)
            p.resetBasePositionAndOrientation(ped.body_id,
                                             [float(ped.xy[0]), float(ped.xy[1]), 0.9/2 + ped.radius],
                                             p.getQuaternionFromEuler([0,0,ped.yaw]))

    def get_lidar_scan(self) -> Tuple[np.ndarray, np.ndarray]:
        """Returns (hit_fraction, hit_positions_xyz) for rays.

        Ray origins are at robot top center, directions span azimuth and elevation.
        """
        base_pos, base_orn = p.getBasePositionAndOrientation(self.robot_id)
        rx, ry, rz = base_pos
        yaw = p.getEulerFromQuaternion(base_orn)[2]

        origins = []
        targets = []

        az = np.linspace(-math.pi, math.pi, self.lidar.n_az, endpoint=False)
        el = np.radians(np.array(self.lidar.el_deg, dtype=float))
        for e in el:
            for a in az:
                ang = a + yaw
                dx = math.cos(ang) * math.cos(e)
                dy = math.sin(ang) * math.cos(e)
                dz = math.sin(e)
                origins.append([rx, ry, rz + 0.20])
                targets.append([rx + dx * self.lidar.max_range,
                                ry + dy * self.lidar.max_range,
                                rz + dz * self.lidar.max_range])

        results = p.rayTestBatch(origins, targets)
        hit_frac = np.array([r[2] for r in results], dtype=float)
        hit_pos = np.array([r[3] for r in results], dtype=float)
        return hit_frac, hit_pos

    def apply_control(self, v: float, w: float):
        v = float(np.clip(v, -self.max_v, self.max_v))
        w = float(np.clip(w, -self.max_w, self.max_w))
        # Update kinematic pose (planning state)
        self.robot_pose = integrate_diff_drive(self.robot_pose, v, w, self.dt)
        h = float(self.cfg['robot']['height'])
        p.resetBasePositionAndOrientation(self.robot_id,
                                         [self.robot_pose.x, self.robot_pose.y, h/2],
                                         p.getQuaternionFromEuler([0,0,self.robot_pose.yaw]))

    def step(self, v: float, w: float):
        self._step_pedestrians()
        self.apply_control(v, w)
        p.stepSimulation()

    def state(self) -> dict:
        # Return minimal state needed by planner
        return {
            'pose': self.robot_pose.copy(),
            'goal_xy': self.goal[:2].copy(),
            'pedestrians': [
                {
                    'xy': ped.xy.copy(),
                    'yaw': ped.yaw,
                    'vel': ped.vel.copy(),
                    'radius': ped.radius,
                    'ps': ped.ps,
                } for ped in self.pedestrians
            ],
        }



    def get_state(self):
        return self.robot_pose.copy()

    def get_pedestrians_state(self):
        return [
            {'xy': ped.xy.copy(), 'yaw': ped.yaw, 'vel': ped.vel.copy(), 'ps': ped.ps, 'radius': ped.radius}
            for ped in self.pedestrians
        ]

    def lidar_min_distance(self) -> float:
        _, dists = self.get_lidar_scan()
        if dists.size == 0:
            return float('inf')
        return float(dists.min())

    def reached_goal(self, tol: float = 0.5) -> bool:
        d = np.linalg.norm(self.robot_pose.xy() - self.goal_xy)
        return d <= tol

    def plot_topdown(self, ax):
        # world bounds
        sx, sy = self.cfg['world']['size_xy']
        ax.set_xlim(0, sx)
        ax.set_ylim(0, sy)
        ax.set_aspect('equal', 'box')

        # obstacles
        for ob in self.cfg['world'].get('obstacles', []):
            pos = ob['pos']
            hx, hy, _ = ob['half_extents']
            ax.add_patch(__import__('matplotlib').patches.Rectangle(
                (pos[0]-hx, pos[1]-hy), 2*hx, 2*hy, fill=False
            ))

        # pedestrians (current)
        for ped in self.pedestrians:
            ax.add_patch(__import__('matplotlib').patches.Circle(
                (float(ped.xy[0]), float(ped.xy[1])), float(ped.radius), fill=False
            ))

        # start/goal markers
        ax.scatter([self.start[0]], [self.start[1]], marker='o')
        ax.scatter([self.goal_xy[0]], [self.goal_xy[1]], marker='*')
